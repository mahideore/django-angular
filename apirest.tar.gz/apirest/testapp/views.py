from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def emp_data_view(request):
    emp_data={
        'eno':100,
        'ename':'mahesh',
        'esal':1000,
        'eaddr':'nashik',

    }
    resp ='emp number:{}<br>emp name:{}<br>emp sal:{}<br>emp address:{}'.format(emp_data['eno'],emp_data['ename'],emp_data['esal'],emp_data['eaddr'])
    return HttpResponse(resp)

import json
def emp_data_jsonview(request):
    emp_data1=[{
        'eno':100,
        'ename':'mahesh',
        'esal':1000,
        'eaddr':'nashik',
        },
        {
        'eno':100,
        'ename':'mahesh',
        'esal':1000,
        'eaddr':'nashik',
    }]
    a=json.dumps(emp_data1)
    return HttpResponse(a,content_type='application/json')

from django.http import JsonResponse
def emp_data_jsonview2(request):
    emp_data={
        'eno':100,
        'ename':'mahesh',
        'esal':1000,
        'eaddr':'nashik',
    }
    return  JsonResponse(emp_data)
    #class based json
from django.views.generic import View
class JsonCBV(View):
    def get(self,request,*args,**kawargs):
        emp_data={
        'eno':100,
        'ename':'mahesh',
        'esal':1000,
        'eaddr':'nashik',
        }
        return JsonResponse(emp_data)
   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    """def post(self,request,*args,**kawargs):
        print("asdfghjklsdfghjklsdfghjkk")
        emp_data={
        'eno':100,
        'ename':'mahi',
        'esal':1000,
        'eaddr':'kalwan',
        }   
        return JsonResponse(emp_data)
    
    class JsonCBV(View):
        def post(self,request,*args,**kawargs):
            json_data=json.dumps(emp_data)
            return HttpResponse(json_data,content_type='application/json')
    """
   